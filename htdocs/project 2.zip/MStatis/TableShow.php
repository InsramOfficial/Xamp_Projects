<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="header.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Website Menu #4</title>
</head>

<body>
   
    <!-- Three Dropdowns -->
    <div class="container mt-4">
    <div class="row">
        <div class="col-lg-3 col-md-4 col-sm-6">
            <div class="form-group">
                <label for="dropdown1">Category:</label>
                <select class="form-control" id="dropdown1">
                    <option value="option1">Option 1</option>
                    <option value="option2">Option 2</option>
                    <option value="option3">Option 3</option>
                </select>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-6">
            <div class="form-group">
                <label for="dropdown4">Location</label>
                <select class="form-control" id="dropdown4">
                    <option value="option1">Option 1</option>
                    <option value="option2">Option 2</option>
                    <option value="option3">Option 3</option>
                </select>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-6">
            <div class="form-group">
                <label for="dropdown2">Year</label>
                <select class="form-control" id="dropdown2">
                    <option value="option1">Option 1</option>
                    <option value="option2">Option 2</option>
                    <option value="option3">Option 3</option>
                </select>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-6">
            <div class="form-group">
                <label for="dropdown3">Month</label>
                <select class="form-control" id="dropdown3">
                    <option value="option1">Option 1</option>
                    <option value="option2">Option 2</option>
                    <option value="option3">Option 3</option>
                </select>
            </div>
        </div>
        
    </div>
</div>

    <!-- Table -->
    <div class="container mt-2">
        <div class="table-container" style="overflow-x: auto;">
        <table class="table table-hover">
  <thead>

                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Email</th>
                        <th>Email</th>
                        <th>Email</th>
                    </tr>
                </thead>

                <tbody>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>

                    </tr>
                    <tr>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>

                    </tr>
                    </tr>
                    <tr>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>

                    </tr>
                    </tr>
                    <tr>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>

                    </tr>
                    </tr>
                    <tr>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>

                    </tr>
                    </tr>


                    <tr>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>

                    </tr>
                    </tr>
                    <tr>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>

                    </tr>
                    </tr>
                    <tr>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>

                    </tr>
                    </tr>
                    <tr>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>
                        <td>123.34</td>

                    </tr>
                    </tr>


                </tbody>
                </tbody>
            </table>
        </div>

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/main.js"></script>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
            crossorigin="anonymous"></script>
            <script>
                // Get references to the navigation links
                var homeLink = document.getElementById('home-link');
                var productsLink = document.getElementById('products-link');
                var pricingLink = document.getElementById('pricing-link');
                var companyLink = document.getElementById('company-link');
            
                // Function to remove "active" class from all navigation items
                function removeActiveClassFromAll() {
                    var navItems = [homeLink, productsLink, pricingLink, companyLink];
                    navItems.forEach(function (item) {
                        if (item) {
                            item.classList.remove('active');
                        }
                    });
                }
            
                // Add click event listeners to handle the active link behavior
                homeLink.addEventListener('click', function () {
                    removeActiveClassFromAll();
                    homeLink.classList.add('active');
                });
            
                productsLink.addEventListener('click', function () {
                    removeActiveClassFromAll();
                    productsLink.classList.add('active');
                });
            
                pricingLink.addEventListener('click', function () {
                    removeActiveClassFromAll();
                    pricingLink.classList.add('active');
                });
            
                companyLink.addEventListener('click', function () {
                    removeActiveClassFromAll();
                    companyLink.classList.add('active');
                });
            </script>
            

</body>

</html>