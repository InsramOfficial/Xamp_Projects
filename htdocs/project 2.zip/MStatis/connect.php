<?php

$ServerName="Localhost";
$Username="root";
$Password="";
$Database="mubahstats";
// Create connection
$connect = new mysqli($ServerName, $Username, $Password, $Database);

if (!$connect) {
    die("Connection to the database failed: " . mysqli_connect_error());
} 
$sql = "SELECT id, name FROM year";
$result = $connect->query($sql);
?>