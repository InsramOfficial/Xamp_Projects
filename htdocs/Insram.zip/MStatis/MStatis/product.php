<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="index.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Website Menu #4</title>
</head>

<body>
    <nav class="navbar navbar-expand-sm navbar-light" id="neubar">
        <div class="container">
            <a class="navbar-brand" href="#">Muabh Proj</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link mx-2" id="home-link" href="index.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link mx-2" id="products-link" href="product.html">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link mx-2" id="pricing-link" href="#">Pricing</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link mx-2 dropdown-toggle" id="company-link" href="#" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Company
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="#">Blog</a></li>
                            <li><a class="dropdown-item" href="#">About Us</a></li>
                            <li><a class="dropdown-item" href="#">Contact us</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            
        </div>
    </nav>

    <!-- Three Dropdowns -->
    <div class="container mt-4">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="form-group">
                    <label for="dropdown1">Category:</label>
                    <select class="form-control" id="dropdown1">
                        <option value="option1">Option 1</option>
                        <option value="option2">Option 2</option>
                        <option value="option3">Option 3</option>
                    </select>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="form-group">
                    <label for="dropdown2">Year</label>
                    <select class="form-control" id="dropdown2">
                        <option value="option1">Option 1</option>
                        <option value="option2">Option 2</option>
                        <option value="option3">Option 3</option>
                    </select>
                </div>
            </div>
            <div class="col-lg-4 col-md-12">
                <div class="form-group">
                    <label for="dropdown3">Month </label>
                    <select class="form-control" id="dropdown3">
                        <option value="option1">Option 1</option>
                        <option value="option2">Option 2</option>
                        <option value="option3">Option 3</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

   
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/main.js"></script>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
            crossorigin="anonymous"></script>
            <script>
                // Get references to the navigation links
                var homeLink = document.getElementById('home-link');
                var productsLink = document.getElementById('products-link');
                var pricingLink = document.getElementById('pricing-link');
                var companyLink = document.getElementById('company-link');
            
                // Function to remove "active" class from all navigation items
                function removeActiveClassFromAll() {
                    var navItems = [homeLink, productsLink, pricingLink, companyLink];
                    navItems.forEach(function (item) {
                        if (item) {
                            item.classList.remove('active');
                        }
                    });
                }
            
                // Add click event listeners to handle the active link behavior
                homeLink.addEventListener('click', function () {
                    removeActiveClassFromAll();
                    homeLink.classList.add('active');
                });
            
                productsLink.addEventListener('click', function () {
                    removeActiveClassFromAll();
                    productsLink.classList.add('active');
                });
            
                pricingLink.addEventListener('click', function () {
                    removeActiveClassFromAll();
                    pricingLink.classList.add('active');
                });
            
                companyLink.addEventListener('click', function () {
                    removeActiveClassFromAll();
                    companyLink.classList.add('active');
                });
            </script>
            

</body>

</html>