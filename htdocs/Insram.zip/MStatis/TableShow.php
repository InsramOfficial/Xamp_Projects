<?php
// Initialize variables
$Catid = $Locid = null;

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the ID from the form submission
    $Catid = isset($_POST["category"]) ? (int)$_POST["category"] : 0;
    $Locid = isset($_POST["Location"]) ? (int)$_POST["Location"] : 0;
}

// Check if variables are not defined
if ($Catid === null || $Locid === null) {
    // Display a message asking the user to enter the category and location
  
    // Optionally, you can exit the script here to prevent further execution
    // exit();
}
?>
<?php
require 'connect.php';
require 'DataPostmethod.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="header.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
    <title>Website Menu #4</title>
    <style>
    body {
    margin: 0;
    padding: 0;
  }

  .table-container {
    max-width: 90%;
    max-height: 350px;
    overflow-x: auto;
    overflow-y: auto;
  }

  .table {
    border-collapse: collapse;
    width: 100%;
    margin: 0; /* Remove margin */
    padding: 0; /* Remove padding */
  }

  .table thead th {
    font-weight: bold; /* Make month names bold */
  }

  .table thead th:first-child,
  .table tbody td:first-child {
    position: sticky;
    left: 0;
    z-index: 10;
    background-color: #fff;
    margin-left: 0;
  }

    .custom-scroll {
        max-height: 400px; /* Set the maximum height for the table */
        overflow-y: auto; /* Enable vertical scrolling */
        overflow-x: auto; /* Enable horizontal scrolling */
        border: 1px solid #ddd; /* Add a border for better appearance */
    }

    .custom-scroll table {
        width: 100%; /* Make the table fill the container */
        margin-bottom: 0; /* Remove default table margin */
        white-space: nowrap; /* Prevent text wrapping in table cells */
    }

    .custom-scroll::-webkit-scrollbar {
        width: 8px; /* Set the width of the scrollbar */
        height: 8px; /* Set the height of the scrollbar for horizontal scrollbar */
    }

    .custom-scroll::-webkit-scrollbar-thumb {
        background-color: #888; /* Set the color of the scrollbar thumb */
    }

    .custom-scroll::-webkit-scrollbar-track {
        background-color: #f1f1f1; /* Set the color of the scrollbar track */
    }
/* Sticky header styles */
.table-container table thead {
        position: sticky;
        top: 0;
        background-color: #f8f9fa; /* Set your desired background color */
        z-index: 1000; /* Adjust the z-index as needed */
    }

    /* Remove margin from the first column */
    .table-container table th:first-child {
        margin-left: 0;
    }



    </style>
</head>

<body>

    <!-- Three Dropdowns -->
    <div class="container text-center mt-4">
        <form action="" method="Post">
            <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-4"></div>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="form-group">
                        <?php
                        $sql = "SELECT CategoryID, Category_Name FROM category";
                        $result = $connect->query($sql);
                        ?>
                        <label for="Category">Category</label>
                        <select class="form-control" id="category" name="category">
                            <?php
                            // Populate the dropdown with data from the database
                            echo "<option>---------------Select---------------</option>";
                            while ($row = $result->fetch_assoc()) {
                                $selected = ($row['CategoryID'] == $Catid) ? 'selected' : '';
                                 echo "<option value='" . $row['CategoryID'] . "' $selected>" . $row['Category_Name'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="form-group">
                        <?php
                        $sql = "SELECT LocationId, LocationName FROM locality";
                        $result = $connect->query($sql);
                        ?>
                        <label for="Location">Location</label>
                        <select class="form-control" id="Location" name="Location">
                            <?php
                            echo "<option>---------------Select---------------</option>";
                            // Populate the dropdown with data from the database
                            while ($row = $result->fetch_assoc()) {
                                $selected = ($row['LocationId'] == $Locid) ? 'selected' : '';
                                echo "<option value='" . $row['LocationId'] . "' $selected>" . $row['LocationName'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6"> <button type="submit" class="btn btn-success mt-4">Check</button></div>
            </div>

        </form>
    </div>
    <div class="container table-container custom-scroll rounded">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col"></th>
                    <?php

                  
                    $years = "SELECT 
                    y.YearName,
                    COUNT(*) AS CountPerYear
                FROM 
                    _data AS d
                INNER JOIN 
                    yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
                INNER JOIN 
                    _year AS y ON ymt.YearCode = y.YearCode
                WHERE
                    d.LocationID = '$Locid' AND d.CategoryID = '$Catid'
                GROUP BY 
                    y.YearName";

                    $result = $connect->query($years);

                  
                    while ($row = $result->fetch_assoc()) {
                        echo "<th>" . $row["YearName"] . "</th>";
                    }
                    ?>
                </tr>
            </thead>
            <tbody>
                 <?php
                    $StatisData = "
                        SELECT 
                            d.StatisData AS Statisdata
                        FROM 
                            _data AS d
                        INNER JOIN 
                            yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
                        INNER JOIN 
                            _month AS m ON ymt.MonthCode = m.MonthCode
                        WHERE
                            d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode = 1;
                    ";

                    $Data = $connect->query($StatisData);

                    echo "<tr>";
                    echo "<td><b>Jan</b></td>";

                    while ($row = $Data->fetch_assoc()) {
                        echo "<td>" . $row["Statisdata"] . "</td>";
                    }

                    echo "</tr>";
                    ?>


                <?php
                $StatisData = "
                SELECT 
                d.StatisData AS Statisdata
            FROM 
                _data AS d
            INNER JOIN 
                yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
            INNER JOIN 
                _month AS m ON ymt.MonthCode = m.MonthCode
            WHERE
                d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode = 2;
                  ";
                $Data = $connect->query($StatisData);


                echo "<tr>";
                echo "<td><b>Feb</b></td>";
                // while($row = $result->fetch_assoc())
                // {
                //     echo "<td>". $row["MonthName"]."</td>";
                // }
                while ($row = $Data->fetch_assoc()) {
                    echo "<td>" . $row["Statisdata"] . "</td>";
                }
                echo "</tr>";
                ?>
                <?php
                $StatisData = "
                SELECT 
                d.StatisData AS Statisdata
            FROM 
                _data AS d
            INNER JOIN 
                yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
            INNER JOIN 
                _month AS m ON ymt.MonthCode = m.MonthCode
            WHERE
                d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode = 3;
                  ";
                $Data = $connect->query($StatisData);


                echo "<tr>";
                echo "<td><b>Mar</b></td>";
                
                while ($row = $Data->fetch_assoc()) {
                    echo "<td>" . $row["Statisdata"] . "</td>";
                }
                echo "</tr>";
                ?>
                <?php
                $StatisData = "
                SELECT 
                d.StatisData AS Statisdata
            FROM 
                _data AS d
            INNER JOIN 
                yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
            INNER JOIN 
                _month AS m ON ymt.MonthCode = m.MonthCode
            WHERE
                d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode = 4;
                  ";
                $Data = $connect->query($StatisData);


                echo "<tr>";
                echo "<td><b>Apr</b></td>";
                // while($row = $result->fetch_assoc())
                // {
                //     echo "<td>". $row["MonthName"]."</td>";
                // }
                while ($row = $Data->fetch_assoc()) {
                    echo "<td>" . $row["Statisdata"] . "</td>";
                }
                echo "</tr>";
                ?>
                <?php
                $StatisData = "
                SELECT 
                d.StatisData AS Statisdata
            FROM 
                _data AS d
            INNER JOIN 
                yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
            INNER JOIN 
                _month AS m ON ymt.MonthCode = m.MonthCode
            WHERE
                d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode = 5;
                  ";
                $Data = $connect->query($StatisData);


                echo "<tr>";
                echo "<td><b>May</b></td>";
                // while($row = $result->fetch_assoc())
                // {
                //     echo "<td>". $row["MonthName"]."</td>";
                // }
                while ($row = $Data->fetch_assoc()) {
                    echo "<td>" . $row["Statisdata"] . "</td>";
                }
                echo "</tr>";
                ?>
                <?php
                $StatisData = "
                SELECT 
                d.StatisData AS Statisdata
            FROM 
                _data AS d
            INNER JOIN 
                yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
            INNER JOIN 
                _month AS m ON ymt.MonthCode = m.MonthCode
            WHERE
                d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode = 6;
                  ";
                $Data = $connect->query($StatisData);


                echo "<tr>";
                echo "<td><b>June</b></td>";
                // while($row = $result->fetch_assoc())
                // {
                //     echo "<td>". $row["MonthName"]."</td>";
                // }
                while ($row = $Data->fetch_assoc()) {
                    echo "<td>" . $row["Statisdata"] . "</td>";
                }
                echo "</tr>";
                ?>
                <?php
                $StatisData = "
                SELECT 
                d.StatisData AS Statisdata
            FROM 
                _data AS d
            INNER JOIN 
                yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
            INNER JOIN 
                _month AS m ON ymt.MonthCode = m.MonthCode
            WHERE
                d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode = 7;
                  ";
                $Data = $connect->query($StatisData);


                echo "<tr>";
                echo "<td><b>July</b></td>";
                // while($row = $result->fetch_assoc())
                // {
                //     echo "<td>". $row["MonthName"]."</td>";
                // }
                while ($row = $Data->fetch_assoc()) {
                    echo "<td>" . $row["Statisdata"] . "</td>";
                }
                echo "</tr>";
                ?>
                <?php
                $StatisData = "
                SELECT 
                d.StatisData AS Statisdata
            FROM 
                _data AS d
            INNER JOIN 
                yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
            INNER JOIN 
                _month AS m ON ymt.MonthCode = m.MonthCode
            WHERE
                d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode = 8;
                  ";
                $Data = $connect->query($StatisData);


                echo "<tr>";
                echo "<td><b>Agu</b></td>";
                // while($row = $result->fetch_assoc())
                // {
                //     echo "<td>". $row["MonthName"]."</td>";
                // }
                while ($row = $Data->fetch_assoc()) {
                    echo "<td>" . $row["Statisdata"] . "</td>";
                }
                echo "</tr>";
                ?>
                <?php
                $StatisData = "
                SELECT 
                d.StatisData AS Statisdata
            FROM 
                _data AS d
            INNER JOIN 
                yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
            INNER JOIN 
                _month AS m ON ymt.MonthCode = m.MonthCode
            WHERE
                d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode = 9;
                  ";
                $Data = $connect->query($StatisData);


                echo "<tr>";
                echo "<td><b>Sep</b></td>";
                // while($row = $result->fetch_assoc())
                // {
                //     echo "<td>". $row["MonthName"]."</td>";
                // }
                while ($row = $Data->fetch_assoc()) {
                    echo "<td>" . $row["Statisdata"] . "</td>";
                }
                echo "</tr>";
                ?>
                <?php
                $StatisData = "
                SELECT 
                d.StatisData AS Statisdata
            FROM 
                _data AS d
            INNER JOIN 
                yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
            INNER JOIN 
                _month AS m ON ymt.MonthCode = m.MonthCode
            WHERE
                d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode = 10;
                  ";
                $Data = $connect->query($StatisData);


                echo "<tr>";
                echo "<td><b>Oct</b></td>";
                // while($row = $result->fetch_assoc())
                // {
                //     echo "<td>". $row["MonthName"]."</td>";
                // }
                while ($row = $Data->fetch_assoc()) {
                    echo "<td>" . $row["Statisdata"] . "</td>";
                }
                echo "</tr>";
                ?>
                <?php
                $StatisData = "
                SELECT 
                d.StatisData AS Statisdata
            FROM 
                _data AS d
            INNER JOIN 
                yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
            INNER JOIN 
                _month AS m ON ymt.MonthCode = m.MonthCode
            WHERE
                d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode = 11;
                  ";
                $Data = $connect->query($StatisData);


                echo "<tr>";
                echo "<td><b>Nov</b></td>";
                // while($row = $result->fetch_assoc())
                // {
                //     echo "<td>". $row["MonthName"]."</td>";
                // }
                while ($row = $Data->fetch_assoc()) {
                    echo "<td>" . $row["Statisdata"] . "</td>";
                }
                echo "</tr>";
                ?>
                <?php
                $StatisData = "
                SELECT 
                d.StatisData AS Statisdata
            FROM 
                _data AS d
            INNER JOIN 
                yearmonthtable AS ymt ON d.YMCode = ymt.YearMonthCode
            INNER JOIN 
                _month AS m ON ymt.MonthCode = m.MonthCode
            WHERE
                d.LocationID = '$Locid' AND d.CategoryID = '$Catid' AND m.MonthCode =12;
                  ";
                $Data = $connect->query($StatisData);


                echo "<tr>";
                echo "<td><b>Dec</b></td>";
                // while($row = $result->fetch_assoc())
                // {
                //     echo "<td>". $row["MonthName"]."</td>";
                // }
                while ($row = $Data->fetch_assoc()) {
                    echo "<td>" . $row["Statisdata"] . "</td>";
                }
                echo "</tr>";
                ?>
            </tbody>
        </table>
    </div>
   

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/main.js"></script>
</body>

</html>-