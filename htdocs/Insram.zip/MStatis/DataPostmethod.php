<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    // Get the ID from the form submission
    $Catid = isset($_POST["category"]) ? (int)$_POST["category"] : 0;
    $Locid = isset($_POST["Location"]) ? (int)$_POST["Location"] : 0;
}

?>