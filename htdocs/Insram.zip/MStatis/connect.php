<?php

$ServerName="Localhost";
$Username="root";
$Password="";
$Database="mubahstats";
// Create connection
$connect = new mysqli($ServerName, $Username, $Password, $Database);
?>